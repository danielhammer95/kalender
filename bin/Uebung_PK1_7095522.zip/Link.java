
public class Link <T extends Appointment>{
	
	public T daten;
	public Link naechster;
	
	public Link(T daten, Link naechster)
	{
		this.daten=daten;
		this.naechster=naechster;
	}
	public T getDaten()
	{
		return daten;
	}
	
	public void setDaten(T daten)
	{
		this.daten=daten;
	}
}
